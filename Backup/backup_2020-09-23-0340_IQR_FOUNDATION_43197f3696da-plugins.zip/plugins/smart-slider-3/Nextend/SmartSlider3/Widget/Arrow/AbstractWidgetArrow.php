<?php


namespace Nextend\SmartSlider3\Widget\Arrow;


use Nextend\SmartSlider3\Widget\AbstractWidget;

abstract class AbstractWidgetArrow extends AbstractWidget {

    protected $key = 'widget-arrow-';

}